import json
import enum
import pandas
from typing import List

class Type(enum.EnumMeta):
    any = 'any'
    number = 'number'
    boolean = 'boolean'
    string = 'string'

class Dimensionality(enum.EnumMeta):
    scalar = 'scalar'
    matrix = 'matrix'

class ParameterInfo:
    def __init__(self, type: Type = Type.any, dimensionality: Dimensionality = Dimensionality.scalar, name:str = None, description: str = None):
        self.name = name
        self.type = type
        self.dimensionality = dimensionality
        self.description = description


class FunctionResultInfo:
    def __init__(self):
        self.dimensionality = Dimensionality.scalar

class FunctionInfo:
    def __init__(self):
        self.id = None
        self.name = None
        self.description = None
        self.parameters = None
        self.result = None

class MetadataInfo:
    def __init__(self):
        # Add the built-in function
        codeFunc = FunctionInfo()
        codeFunc.id = 'python'
        codeFunc.name = 'PYTHON'
        codeFunc.description = 'Run Python code'
        del codeFunc.result

        codeParam = ParameterInfo()
        codeParam.name = 'code'
        codeParam.type = Type.string
        codeFunc.parameters = [codeParam]

        self.functions: List[FunctionInfo] = [codeFunc]


class CustomFunctionRegistration:
    instance: 'CustomFunctionRegistration' = None

    def __init__(self):
        self._metadata = MetadataInfo()
        self._functionMap = dict()
        return

    @property
    def metadata(self) -> MetadataInfo:
        return self._metadata

    def getFunction(self, id: str):
        return self._functionMap.get(id, None)

    def add(self, function, id: str, name: str, description: str, parameters: List[ParameterInfo], resultDimensionality: Dimensionality) -> FunctionInfo:
        func = FunctionInfo()
        func.id = id
        self._functionMap[id] = function

        if name is not None and len(name) > 0:
            func.name = name
        else:
            func.name = id

        if description is not None and len(description) > 0:
            func.description = description
        else:
            del func.description

        if parameters is not None and len(parameters) > 0:
            func.parameters = parameters
            for par in func.parameters:
                if par.description is None or len(par.description) == 0:
                    del par.description
                if par.dimensionality == Dimensionality.scalar:
                    del par.dimensionality
                if par.type == Type.any:
                    del par.type
        else:
            del func.parameters

        if resultDimensionality == Dimensionality.matrix:
            func.result = FunctionResultInfo()
            func.result.dimensionality = resultDimensionality
        else:
            del func.result

        # remove any existing function with same id or same name
        self._metadata.functions[:] = [item for item in self._metadata.functions if item.id != func.id and item.name != func.name] 
        self._metadata.functions.append(func)
        return func

    def getMetadataJson(self) -> str:
        metadataJson = json.dumps(self.metadata, default = lambda o: o.__dict__)
        return metadataJson

    def clear(self) -> None:
        self._metadata = MetadataInfo()

    @staticmethod
    def register(func, id: str, name: str, description: str, parameters: List[ParameterInfo], resultDimensionality: Dimensionality = Dimensionality.scalar) -> None:
        if CustomFunctionRegistration.instance is None:
            CustomFunctionRegistration.instance = CustomFunctionRegistration()
        CustomFunctionRegistration.instance.add(func, id, name, description, parameters, resultDimensionality)


def customfunction(name: str = None, description: str = None, parameters: List[ParameterInfo] = None, resultDimensionality: Dimensionality = Dimensionality.scalar):
    def register(function):
        id = function.__name__
        parameterNames = function.__code__.co_varnames
        parameterCount = function.__code__.co_argcount
        metadataParameters: List[ParameterInfo] = []
        if parameters is None:
            for i in range(parameterCount):
                par = ParameterInfo()
                par.name = parameterNames[i]
                metadataParameters.append(par)
        else:
            for i in range(parameterCount):
                par = ParameterInfo()
                par.name = parameterNames[i]
                par.type = parameters[i].type
                par.dimensionality = parameters[i].dimensionality
                par.description = parameters[i].description
                metadataParameters.append(par)
        CustomFunctionRegistration.register(function, id, name, description, metadataParameters, resultDimensionality)
        return function
    return register

class InvokeError(enum.IntEnum):
    NoError = 0
    GeneralError = 1
    NotFound = 2

class InvokeResult:
    def __init__(self):
        self.result = None
        self.error = None

def adjustInvokeResult(invokeResult):
    if isinstance(invokeResult.result, pandas.DataFrame):
        invokeResult.result = invokeResult.result.values.tolist()

def invoke(id: str, parameterArrayJsonString: str) -> str:
    ret = InvokeResult()
    if parameterArrayJsonString is None or len(parameterArrayJsonString) == 0:
        parameterArrayJsonString = "[]"
    parameterArray = json.loads(parameterArrayJsonString)
    ret.error = InvokeError.GeneralError
    if CustomFunctionRegistration.instance is not None:
        func = CustomFunctionRegistration.instance.getFunction(id)
        if func is not None:
            ret.result = func(*parameterArray)
            ret.error = InvokeError.NoError

    adjustInvokeResult(ret)
    return json.dumps(ret, default = lambda o: o.__dict__)

def invokeWithPayload(payload) -> str:
    ret = InvokeResult()
    ret.error = InvokeError.GeneralError

    payloadObj = payload
    if isinstance(payload, str):
        payloadObj = json.loads(payload)

    if not isinstance(payloadObj, dict) or not "id" in payloadObj:
        ret.error = InvokeError.GeneralError
    else:
        id = payloadObj.get("id")
        parameterArray = []
        if "parameters" in payloadObj:
            parameterArray = payloadObj.get("parameters")
        
        if CustomFunctionRegistration.instance is None:
            ret.error = InvokeError.NotFound
        else:
            func = CustomFunctionRegistration.instance.getFunction(id)
            if func is None:
                ret.error = InvokeError.NotFound
            else:
                ret.result = func(*parameterArray)
                ret.error = InvokeError.NoError

    adjustInvokeResult(ret)
    return json.dumps(ret, default = lambda o: o.__dict__)

registration = CustomFunctionRegistration.instance
if registration is None:
    CustomFunctionRegistration.instance = CustomFunctionRegistration()
    registration = CustomFunctionRegistration.instance

def getPageHtml(devMode = False) -> str:
    pageHtmlFormat = """
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Custom Functions</title>
    <link rel="stylesheet" href="https://static2.sharepointonline.com/files/fabric/office-ui-fabric-core/9.6.1/css/fabric.min.css">
    <script src="https://{0}/agave/external/react-16-12-0/umd/react.development.js"></script>
    <script src="https://{0}/agave/external/react-dom-16-12-0/umd/react-dom.development.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.5/require.min.js"></script>
    <script type="text/javascript" src="https://appsforoffice.microsoft.com/lib/1.1/hosted/office.debug.js"></script>
    <script type="text/javascript" src="https://{0}/agave/custom-function-forwarder.bundle.js"></script>
</head>
    <body>
        <div id="DivApp">
        </div>
        <div id="DivLog">
        </div>
    </body>
</html>
    """
    if devMode:
        host = "localhost:8080"
    else:
        host = "exceljupyter.azurewebsites.net"
    return pageHtmlFormat.format(host)

if __name__ == "__main__":
    CustomFunctionRegistration.register(None, "sum", "SUM", None, [ParameterInfo(Type.number, name='a'), ParameterInfo(Type.number, name='b')])
    metadataJson = json.dumps(registration.metadata, default = lambda o: o.__dict__)
    print(metadataJson)
    
    @customfunction()
    def testMethod(a, b):
        return a + b

    print(invoke('testMethod', '[2,3]'))
    print('InvokeWithPayload')
    print(invokeWithPayload('{"id": "testMethod", "parameters": [2,3]}'))
    print(getPageHtml(True))
    
    

