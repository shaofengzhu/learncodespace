
def _jupyter_server_extension_paths():
    # path to file containing function load_jupyter_server_extension
    return [{'module': 'officepy.nbserver_extension.server_extension'}]
