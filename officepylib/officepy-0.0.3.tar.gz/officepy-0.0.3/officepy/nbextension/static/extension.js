define(function() { return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/extension.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../../../agave/src/Constants.ts":
/*!**************************************************!*\
  !*** C:/git/exceljupyter/agave/src/Constants.ts ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__, exports], __WEBPACK_AMD_DEFINE_RESULT__ = (function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Constants = void 0;
    var Constants = /** @class */ (function () {
        function Constants() {
        }
        Constants.localStorageKeyCode = 'ExcelJupyterCode';
        Constants.localStorageKeyConnectionUrl = "ExcelJupyterUrl";
        Constants.localStorageKeyConnectionToken = "ExcelJupyterToken";
        Constants.localStorageKeyConnectionNotebookName = "ExcelJupyterNotebookName";
        Constants.localStorageKeyEmbedNotebookUrl = "ExcelJupyterEmbedNotebookUrl";
        Constants.jupyterInputPromptPrefixForApi = "{635FE197-E26B-407E-9C3C-C3C34DC3AFE0}|";
        Constants.jupyterInputPromptPrefixForRichApiRequest = Constants.jupyterInputPromptPrefixForApi + "RICHAPI|";
        Constants.jupyterInputPromptPrefixForOperationMethodRequest = Constants.jupyterInputPromptPrefixForApi + "OPERATIONMETHOD|";
        return Constants;
    }());
    exports.Constants = Constants;
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ "../../../../agave/src/JupyterKernelMessageContracts.ts":
/*!**********************************************************************!*\
  !*** C:/git/exceljupyter/agave/src/JupyterKernelMessageContracts.ts ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*
var msg =
    { "header":
        {
            "msg_id": "960fa11f-be831bb05301a5c2b95b379c",
            "msg_type": "execute_result",
            "username": "username",
            "session": "1ff9a80a-9e20eb2b4ff2d3ad35d10bc2",
            "date": "2019-03-25T04:59:30.661474Z",
            "version": "5.3"
        },
        "msg_id": "960fa11f-be831bb05301a5c2b95b379c",
        "msg_type": "execute_result",
        "parent_header":
            {
                "msg_id": "abe66fa0b98c4c07a8dce0ba5985a6ad",
                "username": "username",
                "session": "84db38e52f6140b087196b72276a456a",
                "msg_type": "execute_request",
                "version": "5.2",
                "date": "2019-03-25T04:59:30.657479Z"
            },
            "metadata": {},
            "content":
                { "data": { "text/plain": "142" }, "metadata": {}, "execution_count": 7 },
            "buffers": [],
            "channel": "iopub"
        };
*/
!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__, exports], __WEBPACK_AMD_DEFINE_RESULT__ = (function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.MessageType = exports.ExecuteReplyContentStatus = void 0;
    var ExecuteReplyContentStatus;
    (function (ExecuteReplyContentStatus) {
        ExecuteReplyContentStatus["ok"] = "ok";
        ExecuteReplyContentStatus["error"] = "error";
    })(ExecuteReplyContentStatus = exports.ExecuteReplyContentStatus || (exports.ExecuteReplyContentStatus = {}));
    var MessageType;
    (function (MessageType) {
        MessageType["execute_result"] = "execute_result";
        MessageType["stream"] = "stream";
        MessageType["execute_reply"] = "execute_reply";
        MessageType["input_request"] = "input_request";
    })(MessageType = exports.MessageType || (exports.MessageType = {}));
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ "./src/extension.ts":
/*!**************************!*\
  !*** ./src/extension.ts ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__, exports, __webpack_require__(/*! ../../../../../agave/src/JupyterKernelMessageContracts */ "../../../../agave/src/JupyterKernelMessageContracts.ts"), __webpack_require__(/*! ../../../../../agave/src/Constants */ "../../../../agave/src/Constants.ts")], __WEBPACK_AMD_DEFINE_RESULT__ = (function (require, exports, JupyterKernelMessageContracts, Constants_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.load_ipython_extension = void 0;
    var g_inputResponseTimeoutSeconds = 30;
    var g_inputAckTimeoutSeconds = 1;
    var g_inputResponseTimeoutHandle = 0;
    var g_inputAckTimeoutHandle = 0;
    var g_jupyterReadyAckReceived = false;
    function getParentWindow() {
        if (window.opener) {
            return window.opener;
        }
        if (window.parent && window.parent !== window) {
            return window.parent;
        }
        return null;
    }
    function sendPostMessageToEventSource(msg, shouldLog, ev) {
        var textMessage = JSON.stringify(msg);
        if (shouldLog) {
            console.log("postMessage: " + textMessage);
        }
        ev.source.postMessage(textMessage, "*");
    }
    function handleWindowMessage(Jupyter, ev) {
        if (!ev || typeof (ev.data) !== "string" || ev.data.length === 0) {
            return;
        }
        var msg;
        try {
            msg = JSON.parse(ev.data);
        }
        catch (ex) {
        }
        if (!msg || !msg.officepy) {
            return;
        }
        // As there could be a lot of ping requests, handle the ping request without logging
        if (msg.officepy.type === "officepy_ping_request") {
            sendPostMessageToEventSource({
                officepy: {
                    type: "officepy_ping_response",
                    request_id: msg.officepy.request_id
                }
            }, false, ev);
            return;
        }
        if (msg.officepy.type === "officepy_jupyter_ready_ack") {
            g_jupyterReadyAckReceived = true;
        }
        else if (msg.officepy.type === "officepy_input_ack") {
            if (g_inputAckTimeoutHandle) {
                clearTimeout(g_inputAckTimeoutHandle);
                g_inputAckTimeoutHandle = 0;
            }
        }
        else if (msg.officepy.type === "officepy_input_response") {
            Jupyter.notebook.kernel.send_input_reply(msg.officepy.value);
            if (g_inputResponseTimeoutHandle) {
                clearTimeout(g_inputResponseTimeoutHandle);
                g_inputResponseTimeoutHandle = 0;
            }
            if (g_inputAckTimeoutHandle) {
                clearTimeout(g_inputAckTimeoutHandle);
                g_inputAckTimeoutHandle = 0;
            }
        }
        else if (msg.officepy.type === "officepy_execute_request") {
            var executionId_1 = msg.officepy.request_id;
            // immediately send ack
            sendPostMessageToEventSource({
                officepy: {
                    type: "officepy_execute_ack",
                    request_id: executionId_1
                }
            }, true, ev);
            var executionExpectResult_1 = msg.officepy.execution_expect_result;
            var jupyterExecuteMessageId_1 = Jupyter.notebook.kernel.execute(msg.officepy.value, {
                shell: {
                    reply: function (jupyterMsg) {
                        if (jupyterMsg.msg_type === JupyterKernelMessageContracts.MessageType.execute_reply) {
                            console.log("executionId:" + executionId_1 + ", status=" + jupyterMsg.content.status);
                            if (jupyterMsg.content.status === JupyterKernelMessageContracts.ExecuteReplyContentStatus.ok) {
                                var responseMsg = {
                                    officepy: {
                                        type: "officepy_execute_response",
                                        request_id: executionId_1,
                                        execute_response_has_value_or_error: false
                                    }
                                };
                                sendPostMessageToEventSource(responseMsg, true, ev);
                                if (!executionExpectResult_1) {
                                    // when executionExpectResult is true, the result will be returned in execute_result 
                                    // and the callback will be cleared there
                                    Jupyter.notebook.kernel.clear_callbacks_for_msg(jupyterExecuteMessageId_1);
                                }
                            }
                            else if (jupyterMsg.content.status === JupyterKernelMessageContracts.ExecuteReplyContentStatus.error) {
                                var errorName = jupyterMsg.content.ename || "GeneralError";
                                var errorMessage = jupyterMsg.content.evalue || "General Error";
                                var responseMsg = {
                                    officepy: {
                                        type: "officepy_execute_response",
                                        request_id: executionId_1,
                                        execute_response_has_value_or_error: true,
                                        error: errorName + ": " + errorMessage
                                    }
                                };
                                sendPostMessageToEventSource(responseMsg, true, ev);
                                Jupyter.notebook.kernel.clear_callbacks_for_msg(jupyterExecuteMessageId_1);
                            }
                        }
                    }
                },
                iopub: {
                    output: function (jupyterMsg) {
                        if (jupyterMsg.msg_type === JupyterKernelMessageContracts.MessageType.execute_result) {
                            var responseMsg = {
                                officepy: {
                                    type: "officepy_execute_response",
                                    request_id: executionId_1,
                                    execute_response_has_value_or_error: true,
                                    value: jupyterMsg.content.data["text/plain"]
                                }
                            };
                            console.log("executionId=" + executionId_1 + ", value=" + jupyterMsg.content.data["text/plain"]);
                            sendPostMessageToEventSource(responseMsg, true, ev);
                            Jupyter.notebook.kernel.clear_callbacks_for_msg(jupyterExecuteMessageId_1);
                        }
                        else if (jupyterMsg.msg_type === JupyterKernelMessageContracts.MessageType.stream &&
                            jupyterMsg.content.name === "stdout") {
                            var responseMsg = {
                                officepy: {
                                    type: "officepy_stdout",
                                    value: jupyterMsg.content.text
                                }
                            };
                            sendPostMessageToEventSource(responseMsg, true, ev);
                        }
                    }
                }
            }, {
                silent: false,
                allow_stdin: true
            });
        }
    }
    function updateKernelPrototype(Jupyter) {
        var proto = Object.getPrototypeOf(Jupyter.notebook.kernel);
        if (!proto._officepy_saved_handle_input_request) {
            proto._officepy_saved_handle_input_request = proto._handle_input_request;
            proto._handle_input_request = function (request) {
                var header = request.header;
                var content = request.content;
                var prefix = Constants_1.Constants.jupyterInputPromptPrefixForApi;
                if (header &&
                    header.msg_type === JupyterKernelMessageContracts.MessageType.input_request &&
                    content &&
                    typeof (content.prompt) === "string" &&
                    content.prompt.substr(0, prefix.length) === prefix) {
                    var msgToParent = {
                        officepy: {
                            type: "officepy_input_request",
                            value: content.prompt
                        }
                    };
                    var parent_1 = getParentWindow();
                    if (g_jupyterReadyAckReceived && parent_1) {
                        parent_1.postMessage(JSON.stringify(msgToParent), "*");
                        // to make sure the kernel is not waiting forever, we will send "Timeout" as reply
                        g_inputResponseTimeoutHandle = window.setTimeout(function () {
                            Jupyter.notebook.kernel.send_input_reply("Timeout");
                        }, g_inputResponseTimeoutSeconds * 1000);
                        g_inputAckTimeoutHandle = window.setTimeout(function () {
                            Jupyter.notebook.kernel.send_input_reply("NotConnected");
                        }, g_inputAckTimeoutSeconds * 1000);
                    }
                    else {
                        Jupyter.notebook.kernel.send_input_reply("NotConnected");
                    }
                }
                else {
                    this._officepy_saved_handle_input_request(request);
                }
            };
        }
    }
    function setup_extension(Jupyter) {
        console.log('officepy.setup_extension');
        window.addEventListener("message", function (ev) {
            handleWindowMessage(Jupyter, ev);
        });
        var readyMessage = {
            officepy: {
                type: "officepy_jupyter_ready"
            }
        };
        var parent = getParentWindow();
        if (parent) {
            parent.postMessage(JSON.stringify(readyMessage), "*");
        }
        updateKernelPrototype(Jupyter);
    }
    function load_ipython_extension() {
        requirejs(["base/js/namespace", "base/js/events"], function (Jupyter, events) {
            if (Jupyter.notebook.kernel) {
                setup_extension(Jupyter);
            }
            else {
                console.log("officepy extension waiting for kernel_ready");
                events.on('kernel_ready.Kernel', function () {
                    setup_extension(Jupyter);
                });
            }
        });
    }
    exports.load_ipython_extension = load_ipython_extension;
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ })

/******/ })});;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL0M6L2dpdC9leGNlbGp1cHl0ZXIvYWdhdmUvc3JjL0NvbnN0YW50cy50cyIsIndlYnBhY2s6Ly8vQzovZ2l0L2V4Y2VsanVweXRlci9hZ2F2ZS9zcmMvSnVweXRlcktlcm5lbE1lc3NhZ2VDb250cmFjdHMudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2V4dGVuc2lvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUNsRkEsaUdBQU8sQ0FBQyxtQkFBUyxFQUFFLE9BQVMsQ0FBQyxtQ0FBRTtBQUMvQjtBQUNBLGtEQUFrRCxjQUFjO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxxQ0FBcUM7QUFDMUY7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsQ0FBQztBQUFBLG9HQUFDOzs7Ozs7Ozs7Ozs7QUNsQkY7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYiwwQkFBMEI7QUFDMUI7QUFDQSxpQkFBaUIsVUFBVSxzQkFBc0IsZ0JBQWdCLHdCQUF3QjtBQUN6RjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFPLENBQUMsbUJBQVMsRUFBRSxPQUFTLENBQUMsbUNBQUU7QUFDL0I7QUFDQSxrREFBa0QsY0FBYztBQUNoRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSywwR0FBMEc7QUFDL0c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSyxnRUFBZ0U7QUFDckUsQ0FBQztBQUFBLG9HQUFDOzs7Ozs7Ozs7Ozs7QUM3Q0YsaUdBQU8sQ0FBQyxtQkFBUyxFQUFFLE9BQVMsRUFBRSwySUFBd0QsRUFBRSxtR0FBb0MsQ0FBQyxtQ0FBRTtBQUMvSDtBQUNBLGtEQUFrRCxjQUFjO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLENBQUM7QUFBQSxvR0FBQyIsImZpbGUiOiJleHRlbnNpb24uanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3NyYy9leHRlbnNpb24udHNcIik7XG4iLCJkZWZpbmUoW1wicmVxdWlyZVwiLCBcImV4cG9ydHNcIl0sIGZ1bmN0aW9uIChyZXF1aXJlLCBleHBvcnRzKSB7XHJcbiAgICBcInVzZSBzdHJpY3RcIjtcclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuICAgIGV4cG9ydHMuQ29uc3RhbnRzID0gdm9pZCAwO1xyXG4gICAgdmFyIENvbnN0YW50cyA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBmdW5jdGlvbiBDb25zdGFudHMoKSB7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIENvbnN0YW50cy5sb2NhbFN0b3JhZ2VLZXlDb2RlID0gJ0V4Y2VsSnVweXRlckNvZGUnO1xyXG4gICAgICAgIENvbnN0YW50cy5sb2NhbFN0b3JhZ2VLZXlDb25uZWN0aW9uVXJsID0gXCJFeGNlbEp1cHl0ZXJVcmxcIjtcclxuICAgICAgICBDb25zdGFudHMubG9jYWxTdG9yYWdlS2V5Q29ubmVjdGlvblRva2VuID0gXCJFeGNlbEp1cHl0ZXJUb2tlblwiO1xyXG4gICAgICAgIENvbnN0YW50cy5sb2NhbFN0b3JhZ2VLZXlDb25uZWN0aW9uTm90ZWJvb2tOYW1lID0gXCJFeGNlbEp1cHl0ZXJOb3RlYm9va05hbWVcIjtcclxuICAgICAgICBDb25zdGFudHMubG9jYWxTdG9yYWdlS2V5RW1iZWROb3RlYm9va1VybCA9IFwiRXhjZWxKdXB5dGVyRW1iZWROb3RlYm9va1VybFwiO1xyXG4gICAgICAgIENvbnN0YW50cy5qdXB5dGVySW5wdXRQcm9tcHRQcmVmaXhGb3JBcGkgPSBcIns2MzVGRTE5Ny1FMjZCLTQwN0UtOUMzQy1DM0MzNERDM0FGRTB9fFwiO1xyXG4gICAgICAgIENvbnN0YW50cy5qdXB5dGVySW5wdXRQcm9tcHRQcmVmaXhGb3JSaWNoQXBpUmVxdWVzdCA9IENvbnN0YW50cy5qdXB5dGVySW5wdXRQcm9tcHRQcmVmaXhGb3JBcGkgKyBcIlJJQ0hBUEl8XCI7XHJcbiAgICAgICAgQ29uc3RhbnRzLmp1cHl0ZXJJbnB1dFByb21wdFByZWZpeEZvck9wZXJhdGlvbk1ldGhvZFJlcXVlc3QgPSBDb25zdGFudHMuanVweXRlcklucHV0UHJvbXB0UHJlZml4Rm9yQXBpICsgXCJPUEVSQVRJT05NRVRIT0R8XCI7XHJcbiAgICAgICAgcmV0dXJuIENvbnN0YW50cztcclxuICAgIH0oKSk7XHJcbiAgICBleHBvcnRzLkNvbnN0YW50cyA9IENvbnN0YW50cztcclxufSk7XHJcbiIsIi8qXHJcbnZhciBtc2cgPVxyXG4gICAgeyBcImhlYWRlclwiOlxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgXCJtc2dfaWRcIjogXCI5NjBmYTExZi1iZTgzMWJiMDUzMDFhNWMyYjk1YjM3OWNcIixcclxuICAgICAgICAgICAgXCJtc2dfdHlwZVwiOiBcImV4ZWN1dGVfcmVzdWx0XCIsXHJcbiAgICAgICAgICAgIFwidXNlcm5hbWVcIjogXCJ1c2VybmFtZVwiLFxyXG4gICAgICAgICAgICBcInNlc3Npb25cIjogXCIxZmY5YTgwYS05ZTIwZWIyYjRmZjJkM2FkMzVkMTBiYzJcIixcclxuICAgICAgICAgICAgXCJkYXRlXCI6IFwiMjAxOS0wMy0yNVQwNDo1OTozMC42NjE0NzRaXCIsXHJcbiAgICAgICAgICAgIFwidmVyc2lvblwiOiBcIjUuM1wiXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIm1zZ19pZFwiOiBcIjk2MGZhMTFmLWJlODMxYmIwNTMwMWE1YzJiOTViMzc5Y1wiLFxyXG4gICAgICAgIFwibXNnX3R5cGVcIjogXCJleGVjdXRlX3Jlc3VsdFwiLFxyXG4gICAgICAgIFwicGFyZW50X2hlYWRlclwiOlxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcIm1zZ19pZFwiOiBcImFiZTY2ZmEwYjk4YzRjMDdhOGRjZTBiYTU5ODVhNmFkXCIsXHJcbiAgICAgICAgICAgICAgICBcInVzZXJuYW1lXCI6IFwidXNlcm5hbWVcIixcclxuICAgICAgICAgICAgICAgIFwic2Vzc2lvblwiOiBcIjg0ZGIzOGU1MmY2MTQwYjA4NzE5NmI3MjI3NmE0NTZhXCIsXHJcbiAgICAgICAgICAgICAgICBcIm1zZ190eXBlXCI6IFwiZXhlY3V0ZV9yZXF1ZXN0XCIsXHJcbiAgICAgICAgICAgICAgICBcInZlcnNpb25cIjogXCI1LjJcIixcclxuICAgICAgICAgICAgICAgIFwiZGF0ZVwiOiBcIjIwMTktMDMtMjVUMDQ6NTk6MzAuNjU3NDc5WlwiXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIFwibWV0YWRhdGFcIjoge30sXHJcbiAgICAgICAgICAgIFwiY29udGVudFwiOlxyXG4gICAgICAgICAgICAgICAgeyBcImRhdGFcIjogeyBcInRleHQvcGxhaW5cIjogXCIxNDJcIiB9LCBcIm1ldGFkYXRhXCI6IHt9LCBcImV4ZWN1dGlvbl9jb3VudFwiOiA3IH0sXHJcbiAgICAgICAgICAgIFwiYnVmZmVyc1wiOiBbXSxcclxuICAgICAgICAgICAgXCJjaGFubmVsXCI6IFwiaW9wdWJcIlxyXG4gICAgICAgIH07XHJcbiovXHJcbmRlZmluZShbXCJyZXF1aXJlXCIsIFwiZXhwb3J0c1wiXSwgZnVuY3Rpb24gKHJlcXVpcmUsIGV4cG9ydHMpIHtcclxuICAgIFwidXNlIHN0cmljdFwiO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xyXG4gICAgZXhwb3J0cy5NZXNzYWdlVHlwZSA9IGV4cG9ydHMuRXhlY3V0ZVJlcGx5Q29udGVudFN0YXR1cyA9IHZvaWQgMDtcclxuICAgIHZhciBFeGVjdXRlUmVwbHlDb250ZW50U3RhdHVzO1xyXG4gICAgKGZ1bmN0aW9uIChFeGVjdXRlUmVwbHlDb250ZW50U3RhdHVzKSB7XHJcbiAgICAgICAgRXhlY3V0ZVJlcGx5Q29udGVudFN0YXR1c1tcIm9rXCJdID0gXCJva1wiO1xyXG4gICAgICAgIEV4ZWN1dGVSZXBseUNvbnRlbnRTdGF0dXNbXCJlcnJvclwiXSA9IFwiZXJyb3JcIjtcclxuICAgIH0pKEV4ZWN1dGVSZXBseUNvbnRlbnRTdGF0dXMgPSBleHBvcnRzLkV4ZWN1dGVSZXBseUNvbnRlbnRTdGF0dXMgfHwgKGV4cG9ydHMuRXhlY3V0ZVJlcGx5Q29udGVudFN0YXR1cyA9IHt9KSk7XHJcbiAgICB2YXIgTWVzc2FnZVR5cGU7XHJcbiAgICAoZnVuY3Rpb24gKE1lc3NhZ2VUeXBlKSB7XHJcbiAgICAgICAgTWVzc2FnZVR5cGVbXCJleGVjdXRlX3Jlc3VsdFwiXSA9IFwiZXhlY3V0ZV9yZXN1bHRcIjtcclxuICAgICAgICBNZXNzYWdlVHlwZVtcInN0cmVhbVwiXSA9IFwic3RyZWFtXCI7XHJcbiAgICAgICAgTWVzc2FnZVR5cGVbXCJleGVjdXRlX3JlcGx5XCJdID0gXCJleGVjdXRlX3JlcGx5XCI7XHJcbiAgICAgICAgTWVzc2FnZVR5cGVbXCJpbnB1dF9yZXF1ZXN0XCJdID0gXCJpbnB1dF9yZXF1ZXN0XCI7XHJcbiAgICB9KShNZXNzYWdlVHlwZSA9IGV4cG9ydHMuTWVzc2FnZVR5cGUgfHwgKGV4cG9ydHMuTWVzc2FnZVR5cGUgPSB7fSkpO1xyXG59KTtcclxuIiwiZGVmaW5lKFtcInJlcXVpcmVcIiwgXCJleHBvcnRzXCIsIFwiLi4vLi4vLi4vLi4vLi4vYWdhdmUvc3JjL0p1cHl0ZXJLZXJuZWxNZXNzYWdlQ29udHJhY3RzXCIsIFwiLi4vLi4vLi4vLi4vLi4vYWdhdmUvc3JjL0NvbnN0YW50c1wiXSwgZnVuY3Rpb24gKHJlcXVpcmUsIGV4cG9ydHMsIEp1cHl0ZXJLZXJuZWxNZXNzYWdlQ29udHJhY3RzLCBDb25zdGFudHNfMSkge1xyXG4gICAgXCJ1c2Ugc3RyaWN0XCI7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XHJcbiAgICBleHBvcnRzLmxvYWRfaXB5dGhvbl9leHRlbnNpb24gPSB2b2lkIDA7XHJcbiAgICB2YXIgZ19pbnB1dFJlc3BvbnNlVGltZW91dFNlY29uZHMgPSAzMDtcclxuICAgIHZhciBnX2lucHV0QWNrVGltZW91dFNlY29uZHMgPSAxO1xyXG4gICAgdmFyIGdfaW5wdXRSZXNwb25zZVRpbWVvdXRIYW5kbGUgPSAwO1xyXG4gICAgdmFyIGdfaW5wdXRBY2tUaW1lb3V0SGFuZGxlID0gMDtcclxuICAgIHZhciBnX2p1cHl0ZXJSZWFkeUFja1JlY2VpdmVkID0gZmFsc2U7XHJcbiAgICBmdW5jdGlvbiBnZXRQYXJlbnRXaW5kb3coKSB7XHJcbiAgICAgICAgaWYgKHdpbmRvdy5vcGVuZXIpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHdpbmRvdy5vcGVuZXI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh3aW5kb3cucGFyZW50ICYmIHdpbmRvdy5wYXJlbnQgIT09IHdpbmRvdykge1xyXG4gICAgICAgICAgICByZXR1cm4gd2luZG93LnBhcmVudDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBzZW5kUG9zdE1lc3NhZ2VUb0V2ZW50U291cmNlKG1zZywgc2hvdWxkTG9nLCBldikge1xyXG4gICAgICAgIHZhciB0ZXh0TWVzc2FnZSA9IEpTT04uc3RyaW5naWZ5KG1zZyk7XHJcbiAgICAgICAgaWYgKHNob3VsZExvZykge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInBvc3RNZXNzYWdlOiBcIiArIHRleHRNZXNzYWdlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZXYuc291cmNlLnBvc3RNZXNzYWdlKHRleHRNZXNzYWdlLCBcIipcIik7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBoYW5kbGVXaW5kb3dNZXNzYWdlKEp1cHl0ZXIsIGV2KSB7XHJcbiAgICAgICAgaWYgKCFldiB8fCB0eXBlb2YgKGV2LmRhdGEpICE9PSBcInN0cmluZ1wiIHx8IGV2LmRhdGEubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIG1zZztcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBtc2cgPSBKU09OLnBhcnNlKGV2LmRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXRjaCAoZXgpIHtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCFtc2cgfHwgIW1zZy5vZmZpY2VweSkge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIEFzIHRoZXJlIGNvdWxkIGJlIGEgbG90IG9mIHBpbmcgcmVxdWVzdHMsIGhhbmRsZSB0aGUgcGluZyByZXF1ZXN0IHdpdGhvdXQgbG9nZ2luZ1xyXG4gICAgICAgIGlmIChtc2cub2ZmaWNlcHkudHlwZSA9PT0gXCJvZmZpY2VweV9waW5nX3JlcXVlc3RcIikge1xyXG4gICAgICAgICAgICBzZW5kUG9zdE1lc3NhZ2VUb0V2ZW50U291cmNlKHtcclxuICAgICAgICAgICAgICAgIG9mZmljZXB5OiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJvZmZpY2VweV9waW5nX3Jlc3BvbnNlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWVzdF9pZDogbXNnLm9mZmljZXB5LnJlcXVlc3RfaWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZmFsc2UsIGV2KTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAobXNnLm9mZmljZXB5LnR5cGUgPT09IFwib2ZmaWNlcHlfanVweXRlcl9yZWFkeV9hY2tcIikge1xyXG4gICAgICAgICAgICBnX2p1cHl0ZXJSZWFkeUFja1JlY2VpdmVkID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAobXNnLm9mZmljZXB5LnR5cGUgPT09IFwib2ZmaWNlcHlfaW5wdXRfYWNrXCIpIHtcclxuICAgICAgICAgICAgaWYgKGdfaW5wdXRBY2tUaW1lb3V0SGFuZGxlKSB7XHJcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQoZ19pbnB1dEFja1RpbWVvdXRIYW5kbGUpO1xyXG4gICAgICAgICAgICAgICAgZ19pbnB1dEFja1RpbWVvdXRIYW5kbGUgPSAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKG1zZy5vZmZpY2VweS50eXBlID09PSBcIm9mZmljZXB5X2lucHV0X3Jlc3BvbnNlXCIpIHtcclxuICAgICAgICAgICAgSnVweXRlci5ub3RlYm9vay5rZXJuZWwuc2VuZF9pbnB1dF9yZXBseShtc2cub2ZmaWNlcHkudmFsdWUpO1xyXG4gICAgICAgICAgICBpZiAoZ19pbnB1dFJlc3BvbnNlVGltZW91dEhhbmRsZSkge1xyXG4gICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KGdfaW5wdXRSZXNwb25zZVRpbWVvdXRIYW5kbGUpO1xyXG4gICAgICAgICAgICAgICAgZ19pbnB1dFJlc3BvbnNlVGltZW91dEhhbmRsZSA9IDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGdfaW5wdXRBY2tUaW1lb3V0SGFuZGxlKSB7XHJcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQoZ19pbnB1dEFja1RpbWVvdXRIYW5kbGUpO1xyXG4gICAgICAgICAgICAgICAgZ19pbnB1dEFja1RpbWVvdXRIYW5kbGUgPSAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKG1zZy5vZmZpY2VweS50eXBlID09PSBcIm9mZmljZXB5X2V4ZWN1dGVfcmVxdWVzdFwiKSB7XHJcbiAgICAgICAgICAgIHZhciBleGVjdXRpb25JZF8xID0gbXNnLm9mZmljZXB5LnJlcXVlc3RfaWQ7XHJcbiAgICAgICAgICAgIC8vIGltbWVkaWF0ZWx5IHNlbmQgYWNrXHJcbiAgICAgICAgICAgIHNlbmRQb3N0TWVzc2FnZVRvRXZlbnRTb3VyY2Uoe1xyXG4gICAgICAgICAgICAgICAgb2ZmaWNlcHk6IHtcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcIm9mZmljZXB5X2V4ZWN1dGVfYWNrXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWVzdF9pZDogZXhlY3V0aW9uSWRfMVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCB0cnVlLCBldik7XHJcbiAgICAgICAgICAgIHZhciBleGVjdXRpb25FeHBlY3RSZXN1bHRfMSA9IG1zZy5vZmZpY2VweS5leGVjdXRpb25fZXhwZWN0X3Jlc3VsdDtcclxuICAgICAgICAgICAgdmFyIGp1cHl0ZXJFeGVjdXRlTWVzc2FnZUlkXzEgPSBKdXB5dGVyLm5vdGVib29rLmtlcm5lbC5leGVjdXRlKG1zZy5vZmZpY2VweS52YWx1ZSwge1xyXG4gICAgICAgICAgICAgICAgc2hlbGw6IHtcclxuICAgICAgICAgICAgICAgICAgICByZXBseTogZnVuY3Rpb24gKGp1cHl0ZXJNc2cpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGp1cHl0ZXJNc2cubXNnX3R5cGUgPT09IEp1cHl0ZXJLZXJuZWxNZXNzYWdlQ29udHJhY3RzLk1lc3NhZ2VUeXBlLmV4ZWN1dGVfcmVwbHkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZXhlY3V0aW9uSWQ6XCIgKyBleGVjdXRpb25JZF8xICsgXCIsIHN0YXR1cz1cIiArIGp1cHl0ZXJNc2cuY29udGVudC5zdGF0dXMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGp1cHl0ZXJNc2cuY29udGVudC5zdGF0dXMgPT09IEp1cHl0ZXJLZXJuZWxNZXNzYWdlQ29udHJhY3RzLkV4ZWN1dGVSZXBseUNvbnRlbnRTdGF0dXMub2spIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2VNc2cgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9mZmljZXB5OiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcIm9mZmljZXB5X2V4ZWN1dGVfcmVzcG9uc2VcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3RfaWQ6IGV4ZWN1dGlvbklkXzEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleGVjdXRlX3Jlc3BvbnNlX2hhc192YWx1ZV9vcl9lcnJvcjogZmFsc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VuZFBvc3RNZXNzYWdlVG9FdmVudFNvdXJjZShyZXNwb25zZU1zZywgdHJ1ZSwgZXYpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZXhlY3V0aW9uRXhwZWN0UmVzdWx0XzEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2hlbiBleGVjdXRpb25FeHBlY3RSZXN1bHQgaXMgdHJ1ZSwgdGhlIHJlc3VsdCB3aWxsIGJlIHJldHVybmVkIGluIGV4ZWN1dGVfcmVzdWx0IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhbmQgdGhlIGNhbGxiYWNrIHdpbGwgYmUgY2xlYXJlZCB0aGVyZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBKdXB5dGVyLm5vdGVib29rLmtlcm5lbC5jbGVhcl9jYWxsYmFja3NfZm9yX21zZyhqdXB5dGVyRXhlY3V0ZU1lc3NhZ2VJZF8xKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChqdXB5dGVyTXNnLmNvbnRlbnQuc3RhdHVzID09PSBKdXB5dGVyS2VybmVsTWVzc2FnZUNvbnRyYWN0cy5FeGVjdXRlUmVwbHlDb250ZW50U3RhdHVzLmVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVycm9yTmFtZSA9IGp1cHl0ZXJNc2cuY29udGVudC5lbmFtZSB8fCBcIkdlbmVyYWxFcnJvclwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlcnJvck1lc3NhZ2UgPSBqdXB5dGVyTXNnLmNvbnRlbnQuZXZhbHVlIHx8IFwiR2VuZXJhbCBFcnJvclwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXNwb25zZU1zZyA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2ZmaWNlcHk6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IFwib2ZmaWNlcHlfZXhlY3V0ZV9yZXNwb25zZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWVzdF9pZDogZXhlY3V0aW9uSWRfMSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4ZWN1dGVfcmVzcG9uc2VfaGFzX3ZhbHVlX29yX2Vycm9yOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3I6IGVycm9yTmFtZSArIFwiOiBcIiArIGVycm9yTWVzc2FnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZW5kUG9zdE1lc3NhZ2VUb0V2ZW50U291cmNlKHJlc3BvbnNlTXNnLCB0cnVlLCBldik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSnVweXRlci5ub3RlYm9vay5rZXJuZWwuY2xlYXJfY2FsbGJhY2tzX2Zvcl9tc2coanVweXRlckV4ZWN1dGVNZXNzYWdlSWRfMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgaW9wdWI6IHtcclxuICAgICAgICAgICAgICAgICAgICBvdXRwdXQ6IGZ1bmN0aW9uIChqdXB5dGVyTXNnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChqdXB5dGVyTXNnLm1zZ190eXBlID09PSBKdXB5dGVyS2VybmVsTWVzc2FnZUNvbnRyYWN0cy5NZXNzYWdlVHlwZS5leGVjdXRlX3Jlc3VsdCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlTXNnID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9mZmljZXB5OiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IFwib2ZmaWNlcHlfZXhlY3V0ZV9yZXNwb25zZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1ZXN0X2lkOiBleGVjdXRpb25JZF8xLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleGVjdXRlX3Jlc3BvbnNlX2hhc192YWx1ZV9vcl9lcnJvcjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGp1cHl0ZXJNc2cuY29udGVudC5kYXRhW1widGV4dC9wbGFpblwiXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImV4ZWN1dGlvbklkPVwiICsgZXhlY3V0aW9uSWRfMSArIFwiLCB2YWx1ZT1cIiArIGp1cHl0ZXJNc2cuY29udGVudC5kYXRhW1widGV4dC9wbGFpblwiXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZW5kUG9zdE1lc3NhZ2VUb0V2ZW50U291cmNlKHJlc3BvbnNlTXNnLCB0cnVlLCBldik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBKdXB5dGVyLm5vdGVib29rLmtlcm5lbC5jbGVhcl9jYWxsYmFja3NfZm9yX21zZyhqdXB5dGVyRXhlY3V0ZU1lc3NhZ2VJZF8xKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChqdXB5dGVyTXNnLm1zZ190eXBlID09PSBKdXB5dGVyS2VybmVsTWVzc2FnZUNvbnRyYWN0cy5NZXNzYWdlVHlwZS5zdHJlYW0gJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1cHl0ZXJNc2cuY29udGVudC5uYW1lID09PSBcInN0ZG91dFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2VNc2cgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2ZmaWNlcHk6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJvZmZpY2VweV9zdGRvdXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGp1cHl0ZXJNc2cuY29udGVudC50ZXh0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbmRQb3N0TWVzc2FnZVRvRXZlbnRTb3VyY2UocmVzcG9uc2VNc2csIHRydWUsIGV2KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgc2lsZW50OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGFsbG93X3N0ZGluOiB0cnVlXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIHVwZGF0ZUtlcm5lbFByb3RvdHlwZShKdXB5dGVyKSB7XHJcbiAgICAgICAgdmFyIHByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKEp1cHl0ZXIubm90ZWJvb2sua2VybmVsKTtcclxuICAgICAgICBpZiAoIXByb3RvLl9vZmZpY2VweV9zYXZlZF9oYW5kbGVfaW5wdXRfcmVxdWVzdCkge1xyXG4gICAgICAgICAgICBwcm90by5fb2ZmaWNlcHlfc2F2ZWRfaGFuZGxlX2lucHV0X3JlcXVlc3QgPSBwcm90by5faGFuZGxlX2lucHV0X3JlcXVlc3Q7XHJcbiAgICAgICAgICAgIHByb3RvLl9oYW5kbGVfaW5wdXRfcmVxdWVzdCA9IGZ1bmN0aW9uIChyZXF1ZXN0KSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgaGVhZGVyID0gcmVxdWVzdC5oZWFkZXI7XHJcbiAgICAgICAgICAgICAgICB2YXIgY29udGVudCA9IHJlcXVlc3QuY29udGVudDtcclxuICAgICAgICAgICAgICAgIHZhciBwcmVmaXggPSBDb25zdGFudHNfMS5Db25zdGFudHMuanVweXRlcklucHV0UHJvbXB0UHJlZml4Rm9yQXBpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGhlYWRlciAmJlxyXG4gICAgICAgICAgICAgICAgICAgIGhlYWRlci5tc2dfdHlwZSA9PT0gSnVweXRlcktlcm5lbE1lc3NhZ2VDb250cmFjdHMuTWVzc2FnZVR5cGUuaW5wdXRfcmVxdWVzdCAmJlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQgJiZcclxuICAgICAgICAgICAgICAgICAgICB0eXBlb2YgKGNvbnRlbnQucHJvbXB0KSA9PT0gXCJzdHJpbmdcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQucHJvbXB0LnN1YnN0cigwLCBwcmVmaXgubGVuZ3RoKSA9PT0gcHJlZml4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIG1zZ1RvUGFyZW50ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvZmZpY2VweToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJvZmZpY2VweV9pbnB1dF9yZXF1ZXN0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogY29udGVudC5wcm9tcHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBhcmVudF8xID0gZ2V0UGFyZW50V2luZG93KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGdfanVweXRlclJlYWR5QWNrUmVjZWl2ZWQgJiYgcGFyZW50XzEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyZW50XzEucG9zdE1lc3NhZ2UoSlNPTi5zdHJpbmdpZnkobXNnVG9QYXJlbnQpLCBcIipcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIG1ha2Ugc3VyZSB0aGUga2VybmVsIGlzIG5vdCB3YWl0aW5nIGZvcmV2ZXIsIHdlIHdpbGwgc2VuZCBcIlRpbWVvdXRcIiBhcyByZXBseVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBnX2lucHV0UmVzcG9uc2VUaW1lb3V0SGFuZGxlID0gd2luZG93LnNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgSnVweXRlci5ub3RlYm9vay5rZXJuZWwuc2VuZF9pbnB1dF9yZXBseShcIlRpbWVvdXRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIGdfaW5wdXRSZXNwb25zZVRpbWVvdXRTZWNvbmRzICogMTAwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdfaW5wdXRBY2tUaW1lb3V0SGFuZGxlID0gd2luZG93LnNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgSnVweXRlci5ub3RlYm9vay5rZXJuZWwuc2VuZF9pbnB1dF9yZXBseShcIk5vdENvbm5lY3RlZFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSwgZ19pbnB1dEFja1RpbWVvdXRTZWNvbmRzICogMTAwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBKdXB5dGVyLm5vdGVib29rLmtlcm5lbC5zZW5kX2lucHV0X3JlcGx5KFwiTm90Q29ubmVjdGVkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX29mZmljZXB5X3NhdmVkX2hhbmRsZV9pbnB1dF9yZXF1ZXN0KHJlcXVlc3QpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIHNldHVwX2V4dGVuc2lvbihKdXB5dGVyKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ29mZmljZXB5LnNldHVwX2V4dGVuc2lvbicpO1xyXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBmdW5jdGlvbiAoZXYpIHtcclxuICAgICAgICAgICAgaGFuZGxlV2luZG93TWVzc2FnZShKdXB5dGVyLCBldik7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdmFyIHJlYWR5TWVzc2FnZSA9IHtcclxuICAgICAgICAgICAgb2ZmaWNlcHk6IHtcclxuICAgICAgICAgICAgICAgIHR5cGU6IFwib2ZmaWNlcHlfanVweXRlcl9yZWFkeVwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIHZhciBwYXJlbnQgPSBnZXRQYXJlbnRXaW5kb3coKTtcclxuICAgICAgICBpZiAocGFyZW50KSB7XHJcbiAgICAgICAgICAgIHBhcmVudC5wb3N0TWVzc2FnZShKU09OLnN0cmluZ2lmeShyZWFkeU1lc3NhZ2UpLCBcIipcIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHVwZGF0ZUtlcm5lbFByb3RvdHlwZShKdXB5dGVyKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIGxvYWRfaXB5dGhvbl9leHRlbnNpb24oKSB7XHJcbiAgICAgICAgcmVxdWlyZWpzKFtcImJhc2UvanMvbmFtZXNwYWNlXCIsIFwiYmFzZS9qcy9ldmVudHNcIl0sIGZ1bmN0aW9uIChKdXB5dGVyLCBldmVudHMpIHtcclxuICAgICAgICAgICAgaWYgKEp1cHl0ZXIubm90ZWJvb2sua2VybmVsKSB7XHJcbiAgICAgICAgICAgICAgICBzZXR1cF9leHRlbnNpb24oSnVweXRlcik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIm9mZmljZXB5IGV4dGVuc2lvbiB3YWl0aW5nIGZvciBrZXJuZWxfcmVhZHlcIik7XHJcbiAgICAgICAgICAgICAgICBldmVudHMub24oJ2tlcm5lbF9yZWFkeS5LZXJuZWwnLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0dXBfZXh0ZW5zaW9uKEp1cHl0ZXIpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIGV4cG9ydHMubG9hZF9pcHl0aG9uX2V4dGVuc2lvbiA9IGxvYWRfaXB5dGhvbl9leHRlbnNpb247XHJcbn0pO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9